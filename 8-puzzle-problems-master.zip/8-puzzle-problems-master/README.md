# 8-puzzle-problems
A java command line program to solve the 8-puzzle problem (and its natural generalizations) using the A* search algorithm
